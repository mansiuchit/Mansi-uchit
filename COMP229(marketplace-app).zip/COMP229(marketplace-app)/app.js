const express = require('express');
const mongoose = require('mongoose');
require('dotenv').config(); // To use environment variables

const app = express();
const port = 3001; // Define the port for your Express app

// MongoDB connection URI from your Atlas dashboard
const url = `mongodb+srv://mansi:${process.env.DB_PASSWORD}@cluster0.dds3y.mongodb.net/marketplace?retryWrites=true&w=majority`;

const clientOptions = { serverApi: { version: '1', strict: true, deprecationErrors: true } };

// Connect to MongoDB
async function connectToMongoDB() {
    try {
        await mongoose.connect(uri, clientOptions);
        await mongoose.connection.db.admin().command({ ping: 1 });
        console.log("Pinged your deployment. You successfully connected to MongoDB!");
    } catch (err) {
        console.error('MongoDB connection error:', err);
    }
}

// Middleware to parse JSON requests
app.use(express.json());

// Connect to MongoDB before starting the server
connectToMongoDB().then(() => {
    app.listen(port, () => {
        console.log(`Server running on http://localhost:${3001}`);
    });
}).catch(console.error);
